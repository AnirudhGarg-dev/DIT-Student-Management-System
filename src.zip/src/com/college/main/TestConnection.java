
package com.college.main;

import java.sql.Connection;
import com.college.util.DBConnection;

public class TestConnection {

    public static void main(String[] args) {
        try (Connection con = DBConnection.getConnection()) {

            System.out.println("MySQL connected successfully!");
            System.out.println("Database: " + con.getCatalog());

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
