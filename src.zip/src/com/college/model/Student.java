
package com.college.model;

import java.time.LocalDate;

public class Student {

    private String name;
    private String gender;
    private String email;
    private String phone;
    private String address;
    private String course;
    private String department;
    private LocalDate dob;
    private int admissionYear;

    public Student(String name, LocalDate dob, String gender,
            String email, String phone, String address,
            String course, String department, int admissionYear) {

        this.name = name;
        this.dob = dob;
        this.gender = gender;
        this.email = email;
        this.phone = phone;
        this.address = address;
        this.course = course;
        this.department = department;
        this.admissionYear = admissionYear;
    }

    public String getName() {
        return name;
    }

    public LocalDate getDob() {
        return dob;
    }

    public String getGender() {
        return gender;
    }

    public String getEmail() {
        return email;
    }

    public String getPhone() {
        return phone;
    }

    public String getAddress() {
        return address;
    }

    public String getCourse() {
        return course;
    }

    public String getDepartment() {
        return department;
    }

    public int getAdmissionYear() {
        return admissionYear;
    }
}
