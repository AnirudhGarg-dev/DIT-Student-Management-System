
package com.college.ui;

import javax.swing.*;
import java.awt.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

import com.college.model.Student;
import com.college.dao.StudentDAO;

public class RegistrationForm extends JFrame {

    private JTextField name = new JTextField();
    private JTextField dob = new JTextField();

    private JComboBox<String> gender = new JComboBox<>(
        new String[]{"Male", "Female", "Other"}
    );

    private JTextField email = new JTextField();
    private JTextField phone = new JTextField();
    private JTextArea address = new JTextArea(3, 20);

    private JComboBox<String> course = new JComboBox<>(
        new String[]{"B.Tech", "BCA", "MCA", "MBA"}
    );

    // Management added to the Department dropdown
    private JComboBox<String> department = new JComboBox<>(
        new String[]{
            "CSE",
            "IT",
            "ECE",
            "Mechanical",
            "Civil",
            "Management"
        }
    );

    private JComboBox<Integer> year = new JComboBox<>(
        new Integer[]{2025, 2026, 2027, 2028, 2029}
    );

    public RegistrationForm() {
        setTitle("DIT University - Student Registration");
        setSize(550, 600);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel form = new JPanel(new GridLayout(0, 2, 10, 10));
        form.setBorder(
            BorderFactory.createEmptyBorder(20, 20, 20, 20)
        );

        addField(form, "Full Name:", name);
        addField(form, "Date of Birth (DD-MM-YYYY):", dob);
        addField(form, "Gender:", gender);
        addField(form, "Email:", email);
        addField(form, "Phone:", phone);
        addField(form, "Address:", new JScrollPane(address));
        addField(form, "Course:", course);
        addField(form, "Department:", department);
        addField(form, "Admission Year:", year);

        JButton register = new JButton("Register");
        JButton clear = new JButton("Clear");

        form.add(register);
        form.add(clear);

        add(form, BorderLayout.CENTER);

        register.addActionListener(e -> registerStudent());
        clear.addActionListener(e -> clearForm());
    }

    private void addField(
            JPanel panel, String label, Component field) {
        panel.add(new JLabel(label));
        panel.add(field);
    }

    private void registerStudent() {
        try {
            String n = name.getText().trim();
            String d = dob.getText().trim();
            String em = email.getText().trim();
            String ph = phone.getText().trim();

            if (n.isEmpty() || d.isEmpty() || em.isEmpty()
                    || ph.isEmpty()) {
                throw new IllegalArgumentException(
                    "Please fill all required fields."
                );
            }

            if (!em.matches(
                    "^[\\w.%+-]+@[\\w.-]+\\.[A-Za-z]{2,}$")) {
                throw new IllegalArgumentException(
                    "Enter a valid email address."
                );
            }

            if (!ph.matches("\\+?[0-9]{10,15}")) {
                throw new IllegalArgumentException(
                    "Enter a valid phone number (10-15 digits)."
                );
            }

            LocalDate birthDate;

            try {
                if (d.matches("\\d{2}-\\d{2}-\\d{4}")) {
                    birthDate = LocalDate.parse(
                        d, DateTimeFormatter.ofPattern("dd-MM-yyyy")
                    );
                } else {
                    birthDate = LocalDate.parse(
                        d, DateTimeFormatter.ISO_LOCAL_DATE
                    );
                }
            } catch (DateTimeParseException ex) {
                throw new IllegalArgumentException(
                    "Enter date as DD-MM-YYYY or YYYY-MM-DD."
                );
            }

            if (birthDate.isAfter(LocalDate.now())) {
                throw new IllegalArgumentException(
                    "Date of birth cannot be in the future."
                );
            }

            Student s = new Student(
                n,
                birthDate,
                (String) gender.getSelectedItem(),
                em,
                ph,
                address.getText().trim(),
                (String) course.getSelectedItem(),
                (String) department.getSelectedItem(),
                (Integer) year.getSelectedItem()
            );

            if (new StudentDAO().addStudent(s)) {
                JOptionPane.showMessageDialog(
                    this,
                    "Registration successful!"
                );
                clearForm();
            } else {
                JOptionPane.showMessageDialog(
                    this,
                    "Registration could not be completed.",
                    "Registration Failed",
                    JOptionPane.ERROR_MESSAGE
                );
            }

        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(
                this,
                ex.getMessage(),
                "Invalid Input",
                JOptionPane.WARNING_MESSAGE
            );

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(
                this,
                "Registration failed: " + ex.getMessage(),
                "Database Error",
                JOptionPane.ERROR_MESSAGE
            );
            ex.printStackTrace();
        }
    }

    private void clearForm() {
        name.setText("");
        dob.setText("");
        email.setText("");
        phone.setText("");
        address.setText("");

        gender.setSelectedIndex(0);
        course.setSelectedIndex(0);
        department.setSelectedIndex(0);
        year.setSelectedItem(2026);
    }
}
