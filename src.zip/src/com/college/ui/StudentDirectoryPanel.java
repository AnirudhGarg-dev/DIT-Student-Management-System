
package com.college.ui;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.util.List;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import com.college.dao.StudentDAO;

public class StudentDirectoryPanel extends JFrame {

    private JTextField searchField;
    private JTable table;
    private DefaultTableModel model;
    private final StudentDAO dao = new StudentDAO();

    public StudentDirectoryPanel() {
        setTitle("DIT University - Student Directory");
        setSize(1000, 550);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout(10, 10));

        // Search panel
        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        searchField = new JTextField(22);

        JButton searchButton = new JButton("Search");
        JButton refreshButton = new JButton("Refresh");

        topPanel.add(new JLabel("Search by ID, name or email:"));
        topPanel.add(searchField);
        topPanel.add(searchButton);
        topPanel.add(refreshButton);

        add(topPanel, BorderLayout.NORTH);

        // Student table
        String[] columns = {
            "Student ID", "Full Name", "Email", "Phone",
            "Course", "Department", "Admission Year"
        };

        model = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        table = new JTable(model);
        table.setAutoCreateRowSorter(true);
        table.setRowHeight(25);

        add(new JScrollPane(table), BorderLayout.CENTER);

        // Action buttons
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));

        JButton editButton = new JButton("Edit Selected");
        JButton deleteButton = new JButton("Delete Selected");
        JButton closeButton = new JButton("Close");

        bottomPanel.add(editButton);
        bottomPanel.add(deleteButton);
        bottomPanel.add(closeButton);

        add(bottomPanel, BorderLayout.SOUTH);

        searchButton.addActionListener(e -> loadStudents());
        searchField.addActionListener(e -> loadStudents());
        refreshButton.addActionListener(e -> {
            searchField.setText("");
            loadStudents();
        });
        editButton.addActionListener(e -> editStudent());
        deleteButton.addActionListener(e -> deleteStudent());
        closeButton.addActionListener(e -> dispose());

        loadStudents();
    }

    private void loadStudents() {
        try {
            List<Object[]> students =
                    dao.getAllStudents(searchField.getText());

            model.setRowCount(0);

            for (Object[] student : students) {
                model.addRow(student);
            }

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this,
                    "Could not load students:\n" + ex.getMessage(),
                    "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private int getSelectedStudentId() {
        int selectedRow = table.getSelectedRow();

        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this,
                    "Please select a student first.");
            return -1;
        }

        int modelRow = table.convertRowIndexToModel(selectedRow);
        return Integer.parseInt(model.getValueAt(modelRow, 0).toString());
    }

    private void editStudent() {
        int id = getSelectedStudentId();

        if (id == -1) {
            return;
        }

        int row = table.convertRowIndexToModel(table.getSelectedRow());

        String name = model.getValueAt(row, 1).toString();
        String email = model.getValueAt(row, 2).toString();
        String phone = model.getValueAt(row, 3).toString();
        String course = model.getValueAt(row, 4).toString();
        String department = model.getValueAt(row, 5).toString();
        String year = model.getValueAt(row, 6).toString();

        JTextField nameField = new JTextField(name);
        JTextField emailField = new JTextField(email);
        JTextField phoneField = new JTextField(phone);
        JTextField courseField = new JTextField(course);
        JTextField departmentField = new JTextField(department);
        JTextField yearField = new JTextField(year);

        JPanel panel = new JPanel(new GridLayout(0, 2, 8, 8));
        panel.add(new JLabel("Full Name:"));
        panel.add(nameField);
        panel.add(new JLabel("Email:"));
        panel.add(emailField);
        panel.add(new JLabel("Phone:"));
        panel.add(phoneField);
        panel.add(new JLabel("Course:"));
        panel.add(courseField);
        panel.add(new JLabel("Department:"));
        panel.add(departmentField);
        panel.add(new JLabel("Admission Year:"));
        panel.add(yearField);

        int result = JOptionPane.showConfirmDialog(this, panel,
                "Edit Student ID: " + id,
                JOptionPane.OK_CANCEL_OPTION,
                JOptionPane.PLAIN_MESSAGE);

        if (result != JOptionPane.OK_OPTION) {
            return;
        }

        try {
            String updatedName = nameField.getText().trim();
            String updatedEmail = emailField.getText().trim();
            String updatedPhone = phoneField.getText().trim();
            String updatedCourse = courseField.getText().trim();
            String updatedDepartment = departmentField.getText().trim();

            if (updatedName.isEmpty() || updatedEmail.isEmpty()
                    || updatedPhone.isEmpty()
                    || updatedCourse.isEmpty()
                    || updatedDepartment.isEmpty()
                    || yearField.getText().trim().isEmpty()) {
                JOptionPane.showMessageDialog(this,
                        "Please fill in all fields.");
                return;
            }

            int admissionYear =
                    Integer.parseInt(yearField.getText().trim());

            boolean updated = dao.updateStudent(id,
                    updatedName, updatedEmail, updatedPhone,
                    updatedCourse, updatedDepartment, admissionYear);

            if (updated) {
                JOptionPane.showMessageDialog(this,
                        "Student updated successfully!");
                loadStudents();
            } else {
                JOptionPane.showMessageDialog(this,
                        "No changes were made.");
            }

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this,
                    "Admission year must be a number.");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this,
                    "Could not update student:\n" + ex.getMessage(),
                    "Update Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void deleteStudent() {
        int id = getSelectedStudentId();

        if (id == -1) {
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(this,
                "Are you sure you want to delete student ID " + id + "?",
                "Confirm Delete",
                JOptionPane.YES_NO_OPTION);

        if (confirm != JOptionPane.YES_OPTION) {
            return;
        }

        try {
            if (dao.deleteStudent(id)) {
                JOptionPane.showMessageDialog(this,
                        "Student deleted successfully!");
                loadStudents();
            } else {
                JOptionPane.showMessageDialog(this,
                        "Student was not found.");
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this,
                    "Could not delete student:\n" + ex.getMessage(),
                    "Delete Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
