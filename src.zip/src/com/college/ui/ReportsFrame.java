
package com.college.ui;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import com.college.util.DBConnection;

public class ReportsFrame extends JFrame {

    private JLabel totalLabel;
    private JLabel courseLabel;
    private JLabel departmentLabel;

    public ReportsFrame() {
        setTitle("DIT University - Reports & Analytics");
        setSize(850, 550);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout(10, 10));

        JPanel summary = new JPanel(new FlowLayout(FlowLayout.CENTER, 30, 15));

        totalLabel = new JLabel("Total Students: ...");
        courseLabel = new JLabel("Courses: ...");
        departmentLabel = new JLabel("Departments: ...");

        summary.add(totalLabel);
        summary.add(courseLabel);
        summary.add(departmentLabel);

        add(summary, BorderLayout.NORTH);

        JTabbedPane tabs = new JTabbedPane();
        tabs.addTab("By Course", createReportTable(
                "SELECT course, COUNT(*) AS total FROM students "
                + "GROUP BY course ORDER BY total DESC",
                "Course"));

        tabs.addTab("By Department", createReportTable(
                "SELECT department, COUNT(*) AS total FROM students "
                + "GROUP BY department ORDER BY total DESC",
                "Department"));

        tabs.addTab("By Admission Year", createReportTable(
                "SELECT admission_year, COUNT(*) AS total FROM students "
                + "GROUP BY admission_year ORDER BY admission_year DESC",
                "Admission Year"));

        add(tabs, BorderLayout.CENTER);

        JButton refreshButton = new JButton("Refresh Reports");
        refreshButton.addActionListener(e -> refreshSummary());

        JPanel bottom = new JPanel();
        bottom.add(refreshButton);
        add(bottom, BorderLayout.SOUTH);

        refreshSummary();
    }

    private JScrollPane createReportTable(String sql, String firstColumn) {
        DefaultTableModel reportModel = new DefaultTableModel(
                new String[] { firstColumn, "Number of Students" }, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        JTable reportTable = new JTable(reportModel);
        reportTable.setRowHeight(25);

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                reportModel.addRow(new Object[] {
                    rs.getObject(1),
                    rs.getInt(2)
                });
            }

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this,
                    "Could not load report:\n" + ex.getMessage(),
                    "Report Error", JOptionPane.ERROR_MESSAGE);
        }

        return new JScrollPane(reportTable);
    }

    private void refreshSummary() {
        String sql = "SELECT COUNT(*), COUNT(DISTINCT course), "
                + "COUNT(DISTINCT department) FROM students";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            if (rs.next()) {
                totalLabel.setText("Total Students: " + rs.getInt(1));
                courseLabel.setText("Courses: " + rs.getInt(2));
                departmentLabel.setText(
                        "Departments: " + rs.getInt(3));
            }

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this,
                    "Could not load summary:\n" + ex.getMessage(),
                    "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
