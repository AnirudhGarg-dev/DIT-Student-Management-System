package com.college.ui;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.college.util.DBConnection;

public class DashboardFrame extends JFrame {

    private final Color NAVY = new Color(22, 34, 66);
    private final Color BLUE = new Color(55, 105, 220);
    private final Color BACKGROUND = new Color(245, 247, 251);

    private JLabel totalStudents;
    private JLabel totalCourses;
    private JLabel totalDepartments;

    public DashboardFrame() {
        setTitle("DIT University | Student Management System");
        setSize(1200, 760);
        setMinimumSize(new Dimension(950, 650));
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        add(createSidebar(), BorderLayout.WEST);
        add(createMainContent(), BorderLayout.CENTER);

        refreshStatistics();
    }

    private JPanel createSidebar() {
        JPanel sidebar = new JPanel();
        sidebar.setBackground(NAVY);
        sidebar.setPreferredSize(new Dimension(230, 0));
        sidebar.setLayout(new BoxLayout(sidebar, BoxLayout.Y_AXIS));
        sidebar.setBorder(new EmptyBorder(25, 15, 20, 15));

        JLabel brand = new JLabel("DIT UNIVERSITY");
        brand.setForeground(Color.WHITE);
        brand.setFont(new Font("SansSerif", Font.BOLD, 20));

        JLabel subtitle = new JLabel("DEHRADUN");
        subtitle.setForeground(new Color(180, 195, 225));
        subtitle.setFont(new Font("SansSerif", Font.PLAIN, 12));

        sidebar.add(brand);
        sidebar.add(Box.createVerticalStrut(5));
        sidebar.add(subtitle);
        sidebar.add(Box.createVerticalStrut(40));

        addMenuButton(sidebar, "Dashboard", () ->
                refreshStatistics());

        addMenuButton(sidebar, "Register Student", () -> {
            new RegistrationForm().setVisible(true);
        });

        addMenuButton(sidebar, "Student Directory", () -> {
            new StudentDirectoryPanel().setVisible(true);
        });

        addMenuButton(sidebar, "Reports & Analytics", () -> {
           new ReportsFrame().setVisible(true);
        });

        addMenuButton(sidebar, "About Project", () -> {
        	 new AboutProjectFrame().setVisible(true);
        });

        sidebar.add(Box.createVerticalGlue());

        JLabel footer = new JLabel("Student Management v1.0");
        footer.setForeground(new Color(180, 195, 225));
        footer.setFont(new Font("SansSerif", Font.PLAIN, 11));
        sidebar.add(footer);

        return sidebar;
    }

    private void addMenuButton(JPanel sidebar, String text,
                               Runnable action) {

        JButton button = new JButton(text);
        button.setAlignmentX(Component.LEFT_ALIGNMENT);
        button.setMaximumSize(new Dimension(Integer.MAX_VALUE, 45));
        button.setPreferredSize(new Dimension(200, 45));
        button.setBackground(NAVY);
        button.setForeground(Color.WHITE);
        button.setFont(new Font("SansSerif", Font.PLAIN, 14));
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setHorizontalAlignment(SwingConstants.LEFT);
        button.setBorder(new EmptyBorder(0, 12, 0, 5));
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));

        button.addActionListener(e -> action.run());

        sidebar.add(button);
        sidebar.add(Box.createVerticalStrut(8));
    }

    private JPanel createMainContent() {
        JPanel main = new JPanel(new BorderLayout(0, 20));
        main.setBackground(BACKGROUND);
        main.setBorder(new EmptyBorder(25, 30, 25, 30));

        JPanel header = new JPanel(new BorderLayout());
        header.setOpaque(false);

        JPanel titles = new JPanel();
        titles.setOpaque(false);
        titles.setLayout(new BoxLayout(titles, BoxLayout.Y_AXIS));

        JLabel heading = new JLabel("Dashboard Overview");
        heading.setFont(new Font("SansSerif", Font.BOLD, 28));
        heading.setForeground(NAVY);

        JLabel description = new JLabel(
                "Welcome to DIT University Student Management");
        description.setFont(new Font("SansSerif", Font.PLAIN, 14));
        description.setForeground(Color.GRAY);

        titles.add(heading);
        titles.add(Box.createVerticalStrut(8));
        titles.add(description);

        JButton registerButton = new JButton("+ Register Student");
        registerButton.setBackground(BLUE);
        registerButton.setForeground(Color.WHITE);
        registerButton.setFocusPainted(false);
        registerButton.setFont(new Font("SansSerif", Font.BOLD, 13));
        registerButton.setBorder(new EmptyBorder(12, 18, 12, 18));

        registerButton.addActionListener(e ->
                new RegistrationForm().setVisible(true));

        header.add(titles, BorderLayout.WEST);
        header.add(registerButton, BorderLayout.EAST);

        JPanel cards = new JPanel(new GridLayout(1, 3, 18, 18));
        cards.setOpaque(false);

        totalStudents = new JLabel("0");
        totalCourses = new JLabel("0");
        totalDepartments = new JLabel("0");

        cards.add(createCard("Total Students", totalStudents));
        cards.add(createCard("Courses Represented", totalCourses));
        cards.add(createCard("Departments Represented",
                totalDepartments));

        JPanel center = new JPanel(new BorderLayout(0, 20));
        center.setOpaque(false);
        center.add(cards, BorderLayout.NORTH);

        JPanel information = new JPanel(new BorderLayout());
        information.setBackground(Color.WHITE);
        information.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(
                        new Color(225, 230, 240)),
                new EmptyBorder(22, 22, 22, 22)));

        JLabel sectionTitle = new JLabel("Quick Actions");
        sectionTitle.setFont(new Font("SansSerif", Font.BOLD, 20));
        sectionTitle.setForeground(NAVY);

        JPanel actions = new JPanel(new GridLayout(2, 2, 15, 15));
        actions.setOpaque(false);
        actions.setBorder(new EmptyBorder(20, 0, 0, 0));

        addAction(actions, "Register a new student",
                () -> new RegistrationForm().setVisible(true));

        addAction(actions, "Refresh statistics",
                this::refreshStatistics);

        addAction(actions, "View student records",
        		() -> new StudentDirectoryPanel().setVisible(true));

        addAction(actions, "About this application",
                () -> JOptionPane.showMessageDialog(this,
                        "DIT University Student Registration System\n"
                        + "Java 21 | Swing | JDBC | MySQL"));

        information.add(sectionTitle, BorderLayout.NORTH);
        information.add(actions, BorderLayout.CENTER);

        center.add(information, BorderLayout.CENTER);

        main.add(header, BorderLayout.NORTH);
        main.add(center, BorderLayout.CENTER);

        return main;
    }

    private JPanel createCard(String title, JLabel value) {
        JPanel card = new JPanel();
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(
                        new Color(225, 230, 240)),
                new EmptyBorder(20, 18, 20, 18)));

        JLabel label = new JLabel(title);
        label.setFont(new Font("SansSerif", Font.PLAIN, 13));
        label.setForeground(Color.GRAY);

        value.setFont(new Font("SansSerif", Font.BOLD, 32));
        value.setForeground(NAVY);

        card.add(label);
        card.add(Box.createVerticalStrut(18));
        card.add(value);

        return card;
    }

    private void addAction(JPanel panel, String text, Runnable action) {
        JButton button = new JButton(text);
        button.setBackground(new Color(247, 249, 253));
        button.setForeground(NAVY);
        button.setFont(new Font("SansSerif", Font.BOLD, 13));
        button.setFocusPainted(false);
        button.addActionListener(e -> action.run());
        panel.add(button);
    }

    private void refreshStatistics() {
        String sql = "SELECT COUNT(*), "
                + "COUNT(DISTINCT course), "
                + "COUNT(DISTINCT department) "
                + "FROM students";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            if (rs.next()) {
                totalStudents.setText(rs.getString(1));
                totalCourses.setText(rs.getString(2));
                totalDepartments.setText(rs.getString(3));
            }

        } catch (Exception ex) {
            totalStudents.setText("--");
            totalCourses.setText("--");
            totalDepartments.setText("--");

            System.err.println(
                    "Unable to load dashboard statistics: "
                    + ex.getMessage());
        }
    }
}