
package com.college.ui;

import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.GridLayout;

import javax.swing.*;

public class AboutProjectFrame extends JFrame {

    public AboutProjectFrame() {

        setTitle("DIT University - About Project");
        setSize(750, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout(15, 15));

        // University heading
        JLabel heading = new JLabel(
                "DIT UNIVERSITY", SwingConstants.CENTER);
        heading.setFont(new Font("SansSerif", Font.BOLD, 28));

        JLabel subtitle = new JLabel(
                "Student Registration & Management System",
                SwingConstants.CENTER);
        subtitle.setFont(new Font("SansSerif", Font.PLAIN, 18));

        JPanel header = new JPanel(new GridLayout(2, 1, 5, 5));
        header.add(heading);
        header.add(subtitle);
        header.setBorder(BorderFactory.createEmptyBorder(
                25, 15, 15, 15));

        add(header, BorderLayout.NORTH);

        // Project details
        JTextArea details = new JTextArea();

        details.setEditable(false);
        details.setLineWrap(true);
        details.setWrapStyleWord(true);
        details.setFont(new Font("SansSerif", Font.PLAIN, 15));
        details.setMargin(new java.awt.Insets(15, 20, 15, 20));

        details.setText(
                "PROJECT INFORMATION\n\n"

                + "Project Title:\n"
                + "Student Registration & Management System\n\n"

                + "SUBMISSION DETAILS\n\n"
                + "Submitted By: Anirudh Garg , Ayush patel, Shubhabrata das\n"
                + "Roll Number: 1000024114 , 1000025662 , 1000025026\n"
                + "Submitted To: Arjun Rai Dutta \n"
                + "University: DIT University, Dehradun\n\n"

                + "PROJECT OVERVIEW\n\n"
                + "This application is designed to manage student "
                + "registration details and student records through "
                + "a desktop-based graphical interface.\n\n"

                + "KEY FEATURES\n\n"
                + "1. Student Registration\n"
                + "2. View and Search Student Records\n"
                + "3. Edit Student Information\n"
                + "4. Delete Student Records\n"
                + "5. Dashboard Statistics\n"
                + "6. Reports by Course\n"
                + "7. Reports by Department\n"
                + "8. Reports by Admission Year\n\n"

                + "TECHNOLOGIES USED\n\n"
                + "Programming Language: Java\n"
                + "Graphical Interface: Java Swing\n"
                + "Database Connectivity: JDBC\n"
                + "Database: MySQL\n"
                + "Development Environment: Eclipse IDE\n\n"

                + "DATABASE INFORMATION\n\n"
                + "Database Name: college_db\n"
                + "Main Table: students\n\n"

                + "PROJECT OBJECTIVE\n\n"
                + "The objective is to provide a simple and organized "
                + "system for maintaining student information, "
                + "retrieving records, updating details, and "
                + "generating basic student reports.\n\n"

                + "FUTURE SCOPE\n\n"
                + "The system can be enhanced with user authentication, "
                + "role-based access, report exports, and additional "
                + "student academic information.\n\n"

                + "Thank you."
        );

        details.setCaretPosition(0);

        JScrollPane scrollPane = new JScrollPane(details);
        add(scrollPane, BorderLayout.CENTER);

        // Close button
        JButton closeButton = new JButton("Close");
        closeButton.addActionListener(e -> dispose());

        JPanel footer = new JPanel();
        footer.add(closeButton);

        add(footer, BorderLayout.SOUTH);
    }
}
